//
//  ViewController.h
//  AfNetworkingSample
//
//  Created by mackbook on 3/16/17.
//  Copyright © 2017 Jabir. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "MBProgressHUD.h"

@interface ViewController : UIViewController
{
    NSMutableDictionary *responseDic;
}


@end

