//
//  AppDelegate.h
//  AfNetworkingSample
//
//  Created by mackbook on 3/16/17.
//  Copyright © 2017 Jabir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

