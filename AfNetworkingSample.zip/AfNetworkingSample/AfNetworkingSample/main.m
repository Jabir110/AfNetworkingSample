//
//  main.m
//  AfNetworkingSample
//
//  Created by mackbook on 3/16/17.
//  Copyright © 2017 Jabir. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
