//
//  ViewController.m
//  AfNetworkingSample
//
//  Created by mackbook on 3/16/17.
//  Copyright © 2017 Jabir. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self ApiCall];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)ApiCall
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
//    [manager.requestSerializer setValue:[NSString stringWithFormat:@"Bearer %@", [defaults valueForKey:@"token"]] forHTTPHeaderField:@"Authorization"];
    
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [manager POST:[NSString stringWithFormat:@"http://ohdeals.com/mobileapp/category_list.php"] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject)
     {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         NSLog(@"%@",responseObject);
         
         responseDic = (NSMutableDictionary *)responseObject;
         
         if ([[responseDic valueForKey:@"status"] isEqualToString:@"success"])
         {
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:[[responseDic valueForKey:@"data"]objectForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
             [alert show];
         }
         
     }
          failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error)
     {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         NSData *errorData = error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey];
         
         if (errorData)
         {
             NSDictionary *serializedData = [NSJSONSerialization JSONObjectWithData: errorData options:kNilOptions error:nil];
             NSLog(@"serializedData: %@",serializedData);
         }
         else
         {
             NSDictionary *noData = @{@"noData": @"No data!"};
             NSLog(@"noData: %@",noData);
         }
     }];
}
@end
